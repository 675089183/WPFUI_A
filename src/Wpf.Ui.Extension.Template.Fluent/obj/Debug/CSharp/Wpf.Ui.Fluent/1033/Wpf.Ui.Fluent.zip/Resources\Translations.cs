namespace $safeprojectname$.Resources
{
    public partial class Translations
    {
    }
}
